package com.Entity;

public class Student {

	Student() {
		System.out.println("Object created : Constructor call");
	}

}
