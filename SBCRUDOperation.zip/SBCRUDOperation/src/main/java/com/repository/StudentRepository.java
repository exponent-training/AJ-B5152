package com.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
	
	@Query(value = "delete from student where id=:sid", nativeQuery = true)
	@Transactional
	@Modifying
	public void deleteStudentById(@Param("sid") int sid);
	
	@Query(value = "select * from student where id=:sid", nativeQuery = true)
	public Student getStudentById(@Param("sid") int sid);

}
