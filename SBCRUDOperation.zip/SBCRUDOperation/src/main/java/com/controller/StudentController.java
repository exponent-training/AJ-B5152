package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Student;
import com.repository.StudentRepository;

@RestController
public class StudentController {

	@Autowired
	private StudentRepository studentRepository;

	@PostMapping("/addStudent")
	public String addStudent(@RequestBody Student student) {

		System.out.println("student controller adding student:");
		if (student != null) {
			studentRepository.save(student);

		} else {
			System.out.println("student doesn't exist!!");
		}
		return "Student addedd successfully..";
	}

	@PostMapping("/addAllStudent")
	public String addListofStudent(@RequestBody List<Student> studentList) {

		if (studentList != null) {
			studentRepository.saveAll(studentList);
			return "students added successfully!!";
		} else {
			return "students list is empty!!";
		}
		
	}

	@DeleteMapping("/deleteStudents")
	public String deleteStudent(@RequestBody List<Student> sList) {
		if (sList != null) {
			studentRepository.deleteAll(sList);
			return "students deleted successfully!!";
		} else {
			return "students list is empty!!";
		}
		
	}
	
	@DeleteMapping("/deleteById/{id}")
	public String deleteStudentById(@PathVariable("id") int stid) {
		studentRepository.deleteStudentById(stid);
		return "student with id= "+ stid +" deleted successfully!!";
	}
	
	@GetMapping("/getStudentById/{id}")
	public Student getStudentById(@PathVariable("id") int stid){
		 Student st = studentRepository.getStudentById(stid);
		 
		 Optional op = Optional.ofNullable(st);
		 
		 System.out.println("student details: "+op.orElse("Student does not exist!!"));
		return st;
	}
	
	
}
