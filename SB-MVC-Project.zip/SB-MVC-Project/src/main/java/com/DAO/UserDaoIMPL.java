package com.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.User;

@Repository
public class UserDaoIMPL implements UserDao {

	@Autowired
	public SessionFactory sf;

	@Override
	public void registerUseinDao(User u) {

		Session session = sf.openSession();
		session.save(u);
		session.beginTransaction().commit();
		System.out.println("User added");

	}

}
