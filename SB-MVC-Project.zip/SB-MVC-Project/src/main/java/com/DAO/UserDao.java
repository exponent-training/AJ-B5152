package com.DAO;

import com.Entity.User;

public interface UserDao {

	public void registerUseinDao(User u);
}
