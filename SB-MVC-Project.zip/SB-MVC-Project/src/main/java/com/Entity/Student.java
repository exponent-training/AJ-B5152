package com.Entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class Student {

}
