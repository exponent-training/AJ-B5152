package com.UserService;

import com.Entity.User;

public interface UserService {

	public void registrUserInService(User u);
}
