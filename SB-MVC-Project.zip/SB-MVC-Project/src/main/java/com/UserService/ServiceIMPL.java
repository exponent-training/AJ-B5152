package com.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.UserDao;
import com.Entity.User;

@Service
public class ServiceIMPL implements UserService {

	@Autowired
	public UserDao ud;

	@Override
	public void registrUserInService(User u) {

		ud.registerUseinDao(u);

	}

}
