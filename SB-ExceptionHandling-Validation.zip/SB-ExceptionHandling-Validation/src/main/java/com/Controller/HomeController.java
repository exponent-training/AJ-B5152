package com.Controller;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.User;
import com.Exception.NullCheck;

@RestController
public class HomeController {

	@PostMapping("/addUser")
	public String getUserData(@Valid @RequestBody User user) throws NullCheck {

		System.out.println("User :- " + user);
		return "OK";

	}
}
