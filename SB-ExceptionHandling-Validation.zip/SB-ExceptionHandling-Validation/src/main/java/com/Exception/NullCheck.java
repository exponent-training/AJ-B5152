package com.Exception;

public class NullCheck extends Exception {

	public NullCheck(String msg) {
		super(msg);
	}
}
