package com.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.val;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = NullCheck.class)
	public ResponseEntity<?> NullCheckingException() {
		return new ResponseEntity("Null Not valid", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(value = MethodArgumentNotValidException.class)
	public ResponseEntity<?> ValidationException(MethodArgumentNotValidException me) {
		return new ResponseEntity(me.getFieldError().getDefaultMessage(), HttpStatus.BAD_REQUEST);
	}
}
