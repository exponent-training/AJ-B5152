package com.Entity;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@Validated
public class User {

	private int uid;

	@NotNull(message = "This field shouldnot be nulll")
	private String uname;

	@Size(min = 2 , max = 10, message = "address must be in between 10 chracters")
	private String uaddress;

//	@Size(max = 60, min = 18, message = "age invalid")
	@Max(value = 60, message = "age invalid")
	private int age;


	@Min(value = 10, message = "phone number must be 10 digit")
	@JsonProperty(value = "ph")
	private int Number;

	private String gender;

}
