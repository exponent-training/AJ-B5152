package com.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name = "HomeController-API-Docs", description = "It container all controller Rest api Only")
public class HomeController {

	@GetMapping("/getDetails")
	public ResponseEntity<?> dummyGetAPI() {
		return new ResponseEntity("This is get call", HttpStatus.OK);
	}

	@PostMapping("/postDetails/{id}")
	public ResponseEntity<?> dummyPOSTAPI(@PathVariable("id") int id) {
		return new ResponseEntity("This is post call" + id, HttpStatus.OK);
	}

	@PostMapping("/putDetails/{id}/{un}")
	public ResponseEntity<?> dummyPUTAPI(@PathVariable("id") int id, @PathVariable("un") String username) {
		return new ResponseEntity("This is post call" + id + " " + username, HttpStatus.OK);
	}
}
