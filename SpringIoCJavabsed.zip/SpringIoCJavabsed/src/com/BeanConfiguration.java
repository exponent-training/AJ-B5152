package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

	@Bean(name = "employees")
	public List<Employee> getEmpList(){
		Employee e1 = new Employee();
		e1.setEid(101);
		e1.setEname("ram");
		e1.setSalary(50000);
		
		Employee e2 = new Employee();
		e2.setEid(102);
		e2.setEname("raj");
		e2.setSalary(80000);
		
		Employee e3 = new Employee();
		e3.setEid(103);
		e3.setEname("gauri");
		e3.setSalary(67000);
		
		Employee e4 = new Employee();
		e4.setEid(104);
		e4.setEname("jay");
		e4.setSalary(34000);
		
		List<Employee> employees = new ArrayList<Employee>();
		
		Collections.addAll(employees, e1,e2,e3,e4);
		
		return employees;
	}
	
	@Bean(name = "company1")
	public Company getCompany() {
		Company c = new Company();
		c.setCid(2001);
		c.setCname("TCS");
		//c.setEmpList(getEmpList());   //Manually
		
		return c;
	}
	
	@Bean(name = "dept")
	public Map<String, String> getDepartment() {
		Department d = new Department();
		d.setDid(7001);
		d.setDname("IT");
		
		Department d1 = new Department();
		d1.setDid(7002);
		d1.setDname("HR");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put(d.getDname(), "Hinjewadi");
		map.put(d1.getDname(), "baner");
		return map;
		
		
	}
}






