package com;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

public class Company {
	
	private int cid;
	
	private String cname;
	
	@Autowired
	private List<Employee> empList;
	
	@Autowired
	private Map<String, String> dnameAndLocation;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	public Map<String, String> getDnameAndLocation() {
		return dnameAndLocation;
	}

	public void setDnameAndLocation(Map<String, String> dnameAndLocation) {
		this.dnameAndLocation = dnameAndLocation;
	}

	@Override
	public String toString() {
		return "Company [cid=" + cid + ", cname=" + cname + ", empList=" + empList + ", dnameAndLocation="
				+ dnameAndLocation + "]";
	}

	

	

	
	

}
