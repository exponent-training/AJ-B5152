package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Companycontroller {
	
	public static void main(String[] args) {
		
		ApplicationContext ac = new AnnotationConfigApplicationContext(BeanConfiguration.class);
		Company companyObj = ac.getBean(Company.class, "company1");
		System.out.println("Company details along with employees:");
		System.out.println(companyObj);
	}

}
