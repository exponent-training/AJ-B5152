package com.ServiceIMPL;

import org.springframework.stereotype.Service;

@Service
public class HomeServiceIMPl {

	public String getCallFormService() {

		return "welcome";

	}

}
