package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
//@RequestMapping(value = "/exponent")
public class RequestController {

	
	@RequestMapping(value = "/log")
	public void getLogRequest(@RequestParam("un") String username , @RequestParam("ps") String password) {
		System.out.println("success");
		System.out.println("Username :-" + username);
		System.out.println("Password :- " + password);
	}
}
