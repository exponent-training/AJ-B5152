package com.Controller;

import javax.jws.soap.SOAPBinding.Use;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.User;
import com.sun.prism.Texture.Usage;

@Controller
//@RequestMapping(value = "/exponent")
public class RequestController {

	private static final String AdminUsername = "admin";
	private static final String AdminPassword = "admin123";

	@RequestMapping(value = "/log")
	public String getLogRequest(@RequestParam("un") String username, @RequestParam("ps") String password, Model model) {
		System.out.println("success");

		if (username.equals(AdminUsername) && password.equals(AdminPassword)) {

			model.addAttribute("msg", "Successfully login");
			return "profile";// webpageName.-> profile.jsp
		} else {
			model.addAttribute("msg", "Invalid Cred");
			return "login";
		}

	}

	@RequestMapping(value = "/reg")
	public String registerUser(@ModelAttribute User user) {
		System.out.println(user);

		return "login";
	}
}
