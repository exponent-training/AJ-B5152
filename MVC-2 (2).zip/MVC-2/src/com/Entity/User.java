package com.Entity;

public class User {
	
	private String uname;
	
	private String uaddress;
	
	private String uadharNo;
	
	private String upassword;
	
	private String ugender;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUaddress() {
		return uaddress;
	}

	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}

	public String getUadharNo() {
		return uadharNo;
	}

	public void setUadharNo(String uadharNo) {
		this.uadharNo = uadharNo;
	}

	public String getUpassword() {
		return upassword;
	}

	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}

	public String getUgender() {
		return ugender;
	}

	public void setUgender(String ugender) {
		this.ugender = ugender;
	}

	@Override
	public String toString() {
		return "User [uname=" + uname + ", uaddress=" + uaddress + ", uadharNo=" + uadharNo + ", upassword=" + upassword
				+ ", ugender=" + ugender + "]";
	}
	
	
	
	
	

}
