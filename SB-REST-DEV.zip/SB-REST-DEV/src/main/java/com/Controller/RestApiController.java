package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class RestApiController {

	@Autowired
	private RestTemplate rt;

	@GetMapping("/getdatafromAPI")
	public ResponseEntity<?> getDetailsFromAPI() {
		String api = "https://jsonplaceholder.typicode.com/users";

		// getForObject , getForEntity

		// getForObject , getForEntity , postForEntity , postForObject , put , delete ,
		// exchange , execute , headForHeaders.

//		String data = rt.getForObject(api, String.class);

//		ResponseEntity<String> entity = rt.getForEntity(api, String.class);
//
//		System.out.println(entity.getBody());
//		System.out.println(entity.getStatusCode());

//		return new ResponseEntity(data, HttpStatus.OK);

		HttpHeaders hh = new HttpHeaders();

		HttpEntity<String> entity = new HttpEntity<String>(hh);

		ResponseEntity<String> exchange = rt.exchange(api, HttpMethod.GET, entity, String.class);

		return exchange;

	}

}
