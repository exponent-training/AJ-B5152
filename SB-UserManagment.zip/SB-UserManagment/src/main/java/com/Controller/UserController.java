package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.DTO.UserDTO;
import com.Model.User;
import com.Service.UserService;

@RestController
@RequestMapping("/exponent/api")
public class UserController {

	@Autowired
	private UserService us;

	@PostMapping(value = "/reg")
	public ResponseEntity<?> registerUser(@RequestBody User user) {
		System.out.println(user);

		us.registerUserInService(user);

		return new ResponseEntity("User added", HttpStatus.OK);

	}

	@GetMapping("/getUsingID/{id}")
	public ResponseEntity<?> getUsingID(@PathVariable("id") int id) {
		UserDTO ud = us.getSingleUserByID(id);
		return new ResponseEntity(ud, HttpStatus.OK);
	}
}
