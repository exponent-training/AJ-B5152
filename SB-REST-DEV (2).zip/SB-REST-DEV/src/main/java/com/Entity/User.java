package com.Entity;

import java.beans.Transient;
import java.util.Date;

import lombok.Data;

@Data
public class User {

	private int uid;

	private String uname;

	private String userEmail;

	private String uaddress;

}
