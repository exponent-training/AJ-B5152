package com.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.Entity.User;

@RestController
public class RestApiController {

	@Autowired
	private RestTemplate rt;

	@GetMapping("/getdatafromAPI")
	public ResponseEntity<?> getDetailsFromAPI() {
		String api = "http://localhost:9005/exponent/api/getAlluser";

		// getForObject , getForEntity

		// getForObject , getForEntity , postForEntity , postForObject , put , delete ,
		// exchange , execute , headForHeaders.

//		String data = rt.getForObject(api, String.class);

//		ResponseEntity<String> entity = rt.getForEntity(api, String.class);
//
//		System.out.println(entity.getBody());
//		System.out.println(entity.getStatusCode());

//		return new ResponseEntity(data, HttpStatus.OK);

		HttpHeaders hh = new HttpHeaders();

		HttpEntity<String> entity = new HttpEntity<String>(hh);

		ResponseEntity<String> exchange = rt.exchange(api, HttpMethod.GET, entity, String.class);

		return exchange;

	}

	@PostMapping("/registerUser")
	public ResponseEntity<?> AddUserInAPI(@RequestBody User user) {
		String api = "http://localhost:9005/exponent/api/useradd";

//		String repsonse = rt.postForObject(api, user, String.class);

		HttpEntity<Object> entity = new HttpEntity<Object>(user);

		ResponseEntity<String> exchange = rt.exchange(api, HttpMethod.POST, entity, String.class);

		return new ResponseEntity(exchange.getBody(), HttpStatus.OK);
	}

	@PutMapping("/upadteUser")
	public ResponseEntity<?> UpdateAPI(@RequestBody User user) {
		String api = "http://localhost:9005/exponent/api/updateUser";
		HttpEntity<Object> entity = new HttpEntity<Object>(user);

		ResponseEntity<String> exchange = rt.exchange(api, HttpMethod.PUT, entity, String.class);

		return new ResponseEntity(exchange.getBody(), HttpStatus.OK);
	}

	@DeleteMapping("/deleteUserByID/{id}")
	public ResponseEntity<?> DeleteAPI(@PathVariable int id) {
		System.out.println(id);
		String api = "http://localhost:9005/exponent/api/deleteBy/" + id;

		rt.delete(api);

		return new ResponseEntity("deleted", HttpStatus.OK);
	}

}
