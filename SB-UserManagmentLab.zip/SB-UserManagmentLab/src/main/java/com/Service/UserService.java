package com.Service;

import com.DTO.UserDTO;
import com.Model.User;

public interface UserService {

	void registerUserInService(User user);

	UserDTO getSingleUserByID(int id);

	public User updateUserDetails(User user);

	User getUserById(int id);
	
	 

}
