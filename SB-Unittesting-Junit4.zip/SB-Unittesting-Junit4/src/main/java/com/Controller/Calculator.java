package com.Controller;

public class Calculator {

	public int addition(int a, int b) {
//		dao layer real dao => dummy dao ->Mock Dao.
		
		return a + b;
	}

	public int multiplication(int a, int b) {
		return a * b;
	}
	
	//usermanagement
	// phonenumber -> 10 digit => pass,fail , name => characters => fail,pass
}
