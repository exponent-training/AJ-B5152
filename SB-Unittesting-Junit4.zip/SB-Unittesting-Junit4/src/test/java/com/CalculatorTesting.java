package com;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;

import com.Controller.Calculator;

@SpringBootTest
public class CalculatorTesting {

	private static Calculator cal;

	@BeforeAll
	public static void CalculatorTesting() {

		cal = new Calculator();

	}

	@Test
	@ParameterizedTest
	@ValueSource(ints = { 10, 20, 30, 40, 50 })
	public void testAddition(int a) {
//		Calculator calci = new Calculator();

		int result = cal.addition(a, 20);

		assertEquals(70, result);

	}

	@Test
	public void testMultiplication() {
//		Calculator calci = new Calculator();

		int result = cal.multiplication(10, 20);

		assertEquals(200, result);

	}

}
