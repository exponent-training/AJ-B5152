package com.Controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Entity.Company;

public class BeansController {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");

		Company cmp1 = apc.getBean("cmp", Company.class);

		System.out.println(cmp1);
//		System.out.println(cmp1.hashCode());
//		System.out.println(cmp1.getEmp().hashCode());

		System.out.println("---------------------------------------------");

		Company cmp2 = apc.getBean("cmp", Company.class);
//		System.out.println(cmp2.hashCode());
//		System.out.println(cmp2.getEmp().hashCode());

	}

}
