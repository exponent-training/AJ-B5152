package com.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import com.Entity.School;
import com.Entity.Student;

@Configuration
public class BeansConfig {

	@Bean(name = "st1")
	@Scope(value = "prototype")
	@Primary
	public Student getStudent() {
		Student st = new Student();
		st.setSid(101);
		st.setSname("Raj");
		st.setSaddress("Pune");

		return st;
	}

	@Bean(name = "st2")
	@Scope(value = "prototype")
	@Primary
	public Student getStudent2() {
		Student st = new Student();
		st.setSid(102);
		st.setSname("karan");
		st.setSaddress("PCMC");

		return st;
	}

	@Bean(name = "st3")
	@Scope(value = "prototype")
	public Student getStudent3() {
		Student st = new Student();
		st.setSid(103);
		st.setSname("ravan");
		st.setSaddress("PCMC");

		return st;
	}

	@Bean(name = "sc1")
	public School getSchoole() {
		School sc = new School();
		sc.setSid(1001);
		sc.setSname("ABC");
		sc.setAdd("PCMC");
//		sc.setStudent(getStudent());

		return sc;
	}
}
