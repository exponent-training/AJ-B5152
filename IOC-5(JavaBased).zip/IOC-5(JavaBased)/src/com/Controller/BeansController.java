package com.Controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.Config.BeansConfig;
import com.Entity.School;
import com.Entity.Student;

public class BeansController {

	public static void main(String[] args) {

		ApplicationContext apc = new AnnotationConfigApplicationContext(BeansConfig.class);

		School sc = apc.getBean("sc1", School.class);
		System.out.println(sc);

	}
}
