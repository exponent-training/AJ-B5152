package com.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class School {

	private int Sid;

	private String sname;

	private String add;

	@Autowired
//	@Qualifier(value = "stu_n")
	private Student student;

	/*
	 * @Autowired private Student student1;
	 */

	/*
	 * public Student getStudent1() { return student1; }
	 * 
	 * public void setStudent1(Student student1) { this.student1 = student1; }
	 */

	public int getSid() {
		return Sid;
	}

	public void setSid(int sid) {
		Sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return "School [Sid=" + Sid + ", sname=" + sname + ", add=" + add + ", student=" + student + "]";
	}

}
