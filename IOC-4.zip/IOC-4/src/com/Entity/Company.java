package com.Entity;

public class Company {

	private String cid;

	private String cname;

	private Employee emp;

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Employee getEmp() {
		return emp;
	}

	public void setEmp(Employee emp) {
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "Company [cid=" + cid + ", cname=" + cname + ", emp=" + emp + "]";
	}

}
