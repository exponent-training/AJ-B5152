package com.ExceptionHandling;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.REUtil;

@ControllerAdvice
public class GlobalExceptionHandling {

	@ExceptionHandler(value = NullPointerException.class)
	public String AllNulllpointerHandleHere() {

		System.out.println("Nullpointer handle here");

		return "error";

	}

	@ExceptionHandler(value = NullValueException.class)
	public String MyCustomeExceptionHandling() {

		return "error";
	}

}
