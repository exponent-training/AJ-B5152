package com.Service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.Entity.User;

public interface UserService {

	public void addUserinService(User user);

	public List<User> getAllUsers();

	public List<User> deleteUserInService(int id);

	public User getUserById(int id);

	public List<User> updateUserInService(User user);

	public void getFileInService(MultipartFile file);

}
