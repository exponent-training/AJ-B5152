package com.Entity;

public class Employee {

}
