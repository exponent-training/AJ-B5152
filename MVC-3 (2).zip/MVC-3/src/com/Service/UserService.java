package com.Service;

import java.util.List;

import com.Entity.User;

public interface UserService {

	public void addUserinService(User user);

	public List<User> getAllUsers();

}
