package com.Service;

import com.Entity.User;

public interface UserService {

	public void addUserinService(User user);

}
