package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Entity.User;
import com.Service.UserService;

@Controller
public class RegisterController {

	@Autowired
	private UserService us;

	@RequestMapping(value = "/reg")
	public String addUser(@ModelAttribute User user) {

		us.addUserinService(user);
		
		return "index";
		
	}
}
