package com.DAO;

import com.Entity.User;

public interface UserDAO {

	public void addUserinDAO(User user);

}
