package com.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.UserDAO;
import com.Entity.User;

@Service
public class ServiceIMPL implements UserService {

	@Autowired
	private UserDAO ud;

	@Override
	public void addUserinService(User user) {

		System.out.println("I am in Service Layer");
		System.out.println(user);

		ud.addUserinDAO(user);

		// buisnessLogic.

	}

	@Override
	public List<User> getAllUsers() {

		List<User> list = ud.getAllUserInDAO();

		return list;
	}

	@Override
	public List<User> deleteUserInService(int id) {

		System.out.println("I am in Service");

		return ud.deleteUserInDao(id);

	}

	@Override
	public User getUserById(int id) {

		return ud.getUserById(id);
	}

	@Override
	public List<User> updateUserInService(User user) {

		return ud.updateUserInDao(user);

	}

}
