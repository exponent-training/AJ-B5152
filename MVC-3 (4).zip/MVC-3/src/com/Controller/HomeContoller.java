package com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.User;
import com.ExceptionHandling.NullValueException;
import com.Service.UserService;

@Controller
public class HomeContoller {

	private static final String adminUsername = "admin";
	private static final String adminPassword = "admin123";

	@Autowired
	private UserService us;

	@RequestMapping(value = "/reg")
	public String addUser(@ModelAttribute User user) {

		us.addUserinService(user);

		return "index";

	}

	@RequestMapping(value = "/log", method = RequestMethod.GET)
	public String LoginUser(@RequestParam("un") String username, @RequestParam("ps") String password, Model model) {

		if (username.equals(adminUsername) && password.equals(adminPassword)) {

			List<User> listOfUsers = us.getAllUsers();

			System.out.println(listOfUsers);

			model.addAttribute("msg", listOfUsers);
			return "details";
		} else {

			model.addAttribute("msg", "Invalid Credentials");
			return "login";
		}

	}

	@RequestMapping(value = "/del")
	public String deleteUser(@RequestParam("uid") int id, Model model) {
		System.out.println("Iam in Controller");
		List<User> updatedList = us.deleteUserInService(id);
		model.addAttribute("msg", updatedList);
		return "details";
	}

	@RequestMapping(value = "/edit")
	public String editUser(@RequestParam("uid") int id, Model model) {
		System.out.println("Iam in Controller");

		User user = us.getUserById(id);

		model.addAttribute("xyz", user);

		return "edituser";
	}

	@RequestMapping(value = "/update")
	public String updateUser(@ModelAttribute User user, Model model) {
		System.out.println("Iam in Controller");

		List<User> list = us.updateUserInService(user);

		model.addAttribute("msg", list);

		return "details";
	}

	/*
	 * @ExceptionHandler(value = NullValueException.class) public String
	 * MyCustomeExceptionHandling() {
	 * 
	 * return "error"; }
	 */
}
