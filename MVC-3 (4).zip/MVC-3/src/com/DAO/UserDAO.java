package com.DAO;

import java.util.List;

import com.Entity.User;

public interface UserDAO {

	public void addUserinDAO(User user);

	public List<User> getAllUserInDAO();

	public List<User> deleteUserInDao(int id);

	public User getUserById(int id);

	public List<User> updateUserInDao(User user);

}
