package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.User;

@Repository
public class UserDaoIMPL implements UserDAO {

	@Autowired
	private SessionFactory sf;

	@Override
	public void addUserinDAO(User user) {

		System.out.println("Iam ins DAO Layer");

		Session s = sf.openSession();
		s.save(user);
		s.beginTransaction().commit();
		System.out.println("User added");

	}

	@Override
	public List<User> getAllUserInDAO() {

		Session s = sf.openSession();
		Query query = s.createQuery("From User");
		List list = query.getResultList();

		return list;
	}

	@Override
	public List<User> deleteUserInDao(int id) {

		System.out.println("I am in Dao");
		Session s = sf.openSession();
		User user = s.get(User.class, id);
		s.delete(user);
		s.beginTransaction().commit();
		System.out.println("Deleted");

		Query query = s.createQuery("From User");
		List list = query.getResultList();

		return list;

	}

	@Override
	public User getUserById(int id) {

		Session s = sf.openSession();
		User user = s.get(User.class, id);

		return user;
	}

	@Override
	public List<User> updateUserInDao(User user) {

		Session s = sf.openSession();
		s.update(user);
		s.beginTransaction().commit();
		System.out.println("updated");

		Query query = s.createQuery("From User");
		List list = query.getResultList();

		return list;
	}

}
