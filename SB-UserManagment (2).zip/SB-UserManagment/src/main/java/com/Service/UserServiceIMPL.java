package com.Service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.DTO.UserDTO;
import com.Model.User;
import com.Repo.UserRepo;

@Service
public class UserServiceIMPL implements UserService {

	@Autowired
	private JavaMailSender jms;

	@Autowired
	private UserRepo ur;

	@Override
	@Transactional
	public void registerUserInService(User user) {

		if (user != null) {

			ur.save(user);

			SimpleMailMessage smm = new SimpleMailMessage();
			smm.setTo("zaidshaikh712002@gmail.com", "mandalkarsachin@gmail.com");
			smm.setSubject("User Registeration completed!!!");
			smm.setText(" Hi Welcome to our Website!!. your username and password is " + user.getPassword() + " - "
					+ user.getUname());

			jms.send(smm);
			
			System.out.println("Success");
		} else {
			System.out.println("User is null");
		}

	}

	@Override
	public UserDTO getSingleUserByID(int id) {

		UserDTO ud = new UserDTO();

		User user = ur.findById(id).get();

		if (user != null) {

			ud.setUname(user.getUname());
			ud.setUPhonenumber(user.getUPhonenumber());
			ud.setUaddress(user.getUaddress());
			ud.setGender(user.getGender());
			return ud;
		} else {

			ud.setMsg("user id is invalid");
			return ud;
		}

	}
}
