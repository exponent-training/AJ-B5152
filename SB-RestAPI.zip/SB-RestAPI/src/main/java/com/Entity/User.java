package com.Entity;

import lombok.Data;

@Data
public class User {

	private int uid;

	private String uname;

	private String uaddress;

}
