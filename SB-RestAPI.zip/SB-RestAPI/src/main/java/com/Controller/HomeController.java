package com.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.User;

@RestController
public class HomeController {

	@GetMapping("/msg")
	public String getMsg() {

		return "Hello how are you!!";
	}

	@PostMapping("/adduser")
	public User registerUser() {
		User user = new User();
		user.setUid(101);
		user.setUname("raj");
		user.setUaddress("pune");

		return user;
	}

	@PostMapping("/getUser")
	public String getUserFromUI(@RequestBody User user) {
		System.out.println(user);

		return "success";
	}

	@PostMapping("/getdatafromqp")
	public String getDataFromQP(@RequestParam("uname") String uname, @RequestParam("uaddress") String address) {
		System.out.println(uname);
		System.out.println(address);

		return uname + " " + address;
	}

	@PostMapping("/getdatafromPP/{uid}/exponent/api/v1/{uname}")
	public String getDataFromQP(@PathVariable("uid") int id, @PathVariable("uname") String name) {
		System.out.println(id);
		System.out.println(name);

		return id + " " + name;
	}

}
