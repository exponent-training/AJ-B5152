package com;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

	Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Value(value = "${name}")
	private String firstName;

	@GetMapping("/")
	public String getMsg() {

		logger.info("This is level");
		logger.debug("this is Debug");
		logger.error("THis is error");
		logger.warn("THis is warn");

		return firstName;
	}
}
