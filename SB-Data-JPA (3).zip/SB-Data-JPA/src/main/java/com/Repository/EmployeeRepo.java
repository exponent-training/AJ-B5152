package com.Repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.Entity.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

	public List<Employee> findByEsalaryGreaterThan(double salary);

	public List<Employee> findByEnameLike(String name);

	public List<Employee> findByOrderByEsalaryDesc();

	@Query(value = "select * from employee", nativeQuery = true)
	public List<Employee> getAllEmployees();

	@Query(value = "update Employee set ename = :name where eid = :id")
	@Transactional
	@Modifying
	public void updateName(@Param("name") String name, @Param("id") int id);

}
