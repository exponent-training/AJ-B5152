package com.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Entity.Employee;
import com.Repository.EmployeeRepo;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepo er;

	@PostMapping("/addemp")
	public String addEmployee(@RequestBody Employee emp) {
		System.out.println("I am in Controller");

		System.out.println(emp);

		if (emp != null) {
			er.save(emp);
			System.out.println("Empoyee save");
			return "Employee added";

		} else {
			return "employee is null";
		}

	}

	@GetMapping("/getcount")
	public String getEmployeeCount() {
		long countAllEmp = er.count();

//		Single ID
//		er.deleteById();

//		List <101,102,103 > -> Ids.
//		er.deleteAllById(list);

//		all elements delete
//		er.deleteAll();

//		list<emp1 , emp2> - Objects.
//		er.deleteAll(list);

//		Single EMployee Object.
//		er.delete(Employee Object);

		return String.valueOf(countAllEmp);
	}

	@GetMapping("/getallemp")
	public List<Employee> getAllDetails() {

//		List<Employee> allEmp = (List<Employee>) er.findAll();
		List<Employee> allEmp = er.getAllEmployees();

		return allEmp;
	}

	@DeleteMapping("/deleteemp")
	public String deleteEmployees() {
//		1. DB throgh.
//		2. postman.

		List<Integer> empIds = new ArrayList<Integer>();

		empIds.add(1);
		empIds.add(2);
		empIds.add(3);

		er.deleteAllById(empIds);

		return "all ids employee deleted";

	}

	// PaginationAndSorting

	// Desc -> salary => input with Proper Validation.
	@GetMapping("/sortbysalaryAsc")
	public List<Employee> SortingExample() {
		List<Employee> empSalaryAsc = er.findAll(Sort.by("esalary").ascending().and(Sort.by("ename").descending()));

		return empSalaryAsc;
	}

//	pagination/
	@GetMapping("/pagination/{page}/{size}")
	public List<Employee> paginationExample(@PathVariable("page") int page, @PathVariable("size") int size) {
		List<Employee> firstTwoEmployeesOnFirstPage = er.findAll(PageRequest.of(page, size)).getContent();
		return firstTwoEmployeesOnFirstPage;
	}

	// salary > 50000.0

	@GetMapping("/getSalGratFiftyT")
	public List<Employee> getEmpSalGreaterFiftyT() {
		List<Employee> esalaryGreaterThan = er.findByEsalaryGreaterThan(50000.0);
		return esalaryGreaterThan;
	}

	@GetMapping("/RsatrtsName")
	public List<Employee> nameLikeR() {
		List<Employee> startsWithR = er.findByEnameLike("r%");
		return startsWithR;
	}
	
	@GetMapping("/ascSalary")
	public List<Employee> ascSalary() {
		List<Employee> ascSalary = er.findByOrderByEsalaryDesc();
		return ascSalary;
	}
	
	
	@PutMapping("/upadteName")
	public String updateName()
	{
		er.updateName("ram", 4);
		return "ok";
	}
	
	
}
