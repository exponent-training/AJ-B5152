package com.ExceptionHandling;

public class NullValueException extends RuntimeException {

	public NullValueException(String msg) {
		super(msg);
	}
}
